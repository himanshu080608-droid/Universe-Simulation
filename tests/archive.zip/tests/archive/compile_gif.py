from PIL import Image
import glob

def make_gif(preset, output):
    frames = []
    files = sorted(glob.glob(f"/tmp/{preset}_frames/frame_*.png"))
    for f in files:
        frames.append(Image.open(f))
    if frames:
        frames[0].save(output, format='GIF', append_images=frames[1:], save_all=True, duration=33, loop=0)
        print(f"Saved {output}")

make_gif("pleiades_m45", "pleiades_pygame.gif")
