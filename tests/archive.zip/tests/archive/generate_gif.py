import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
from universe.generator import build_universe, PIXEL_COLORS
from advanced_engine import AdvancedTaichiEngine

presets = ["pleiades_m45", "omega_centauri"]

def rgb_to_hex(r, g, b):
    return f"#{r:02x}{g:02x}{b:02x}"
mpl_colors = {t: rgb_to_hex(*PIXEL_COLORS[t]) for t in range(12)}

for preset in presets:
    print(f"Generating GIF for {preset}...")
    pos, vel, mass, types = build_universe(preset=preset, N_total=2000) # Lower N for faster rendering
    
    engine = AdvancedTaichiEngine(pos, vel, mass, types, G=1.0, eps=1.0, dt=0.001)
    
    history = []
    
    # Run 60 frames, 32 substeps per frame (16x speed equivalent)
    for f in range(60):
        engine.step(n_substeps=32, speed_mult=1.0)
        history.append(engine.pos.copy())
        
    history = np.array(history)
    
    # Plotting
    fig, ax = plt.subplots(figsize=(6, 6), facecolor='black')
    ax.set_facecolor('black')
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    
    scat = ax.scatter([], [], s=1, c='white')
    
    # Colors
    c_arr = [mpl_colors[t] for t in types]
    
    # Calculate limits (80th percentile to ignore outliers)
    r = np.linalg.norm(pos - np.median(pos, axis=0), axis=1)
    r80 = np.percentile(r, 80)
    limit = max(r80 * 2.0, 5.0)
    
    ax.set_xlim(-limit, limit)
    ax.set_ylim(-limit, limit)
    
    def update(frame):
        p = history[frame]
        scat.set_offsets(p)
        scat.set_color(c_arr)
        return scat,

    ani = animation.FuncAnimation(fig, update, frames=60, blit=True)
    ani.save(f"{preset}.gif", fps=30, writer='pillow')
    plt.close(fig)
    print(f"Saved {preset}.gif!")
