import numpy as np
import time
from hermite_engine import HermiteEngine
from universe.generator import build_universe

def run_test(target_steps, n_substeps, speed_mult):
    p, v, m, t = build_universe("castor_sextuple", N_total=5000, seed=42)
    engine = HermiteEngine(p, v, m, t, dt=0.001, eps=1.0, theta=0.8)
    
    steps_per_loop = int(round(n_substeps * float(speed_mult)))
    if steps_per_loop < 1: steps_per_loop = 1
    
    num_loops = target_steps // steps_per_loop
    
    for _ in range(num_loops):
        engine.step(n_substeps=n_substeps, speed_mult=speed_mult)
        
    remainder = target_steps % steps_per_loop
    if remainder > 0:
        for _ in range(remainder):
            engine._single_hermite_step(engine.dt)
            engine.step_count += 1
            
    return engine.pos.copy()

if __name__ == "__main__":
    TOTAL_STEPS = 100_000
    pos_1x = run_test(TOTAL_STEPS, n_substeps=1, speed_mult=1.0)
    pos_16x = run_test(TOTAL_STEPS, n_substeps=2, speed_mult=16.0)
    
    max_diff = np.max(np.abs(pos_1x - pos_16x))
    print(f"Max Diff at {TOTAL_STEPS} steps: {max_diff}")
