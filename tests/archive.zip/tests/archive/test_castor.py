import numpy as np
from universe.generator import build_universe
from hermite_engine import HermiteEngine
import time

pos, vel, mass, types = build_universe(preset="castor_sextuple", N_total=5000)
engine = HermiteEngine(pos, vel, mass, types, G=1.0, eps=1.0)

t0 = time.time()
print("Starting integration...")
try:
    for step in range(1, 10001):
        engine.step(n_substeps=2, speed_mult=16.0)
        
        if step % 500 == 0:
            max_pos = np.nanmax(np.abs(engine.pos))
            max_vel = np.nanmax(np.abs(engine.vel))
            is_nan = np.isnan(engine.pos).any()
            print(f"Step {step}: max_pos={max_pos:.2e}, max_vel={max_vel:.2e}, has_nan={is_nan}")
            if max_pos > 1e6 or is_nan:
                print("Physics exploded!")
                break
                
except Exception as e:
    print("Crash:", e)

print(f"Done in {time.time()-t0:.2f}s")
