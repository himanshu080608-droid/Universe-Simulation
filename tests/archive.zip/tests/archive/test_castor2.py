import numpy as np
import warnings
warnings.filterwarnings('ignore')
from universe.generator import build_universe
from hermite_engine import HermiteEngine

pos, vel, mass, types = build_universe(preset="castor_sextuple", N_total=5000)
engine = HermiteEngine(pos, vel, mass, types, G=1.0, eps=1.0)

for step in range(1, 4001):
    engine.step(n_substeps=2, speed_mult=16.0)
    if step % 200 == 0:
        max_p = np.nanmax(np.abs(engine.pos))
        print(f"Step {step}: max_pos={max_p:.2e}")
        if max_p > 1e7:
            print("Exploded!")
            break
print("Done!")
