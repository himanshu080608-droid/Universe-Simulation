import os
import sys
import numpy as np
import matplotlib.pyplot as plt

sys.path.append(os.path.dirname(__file__))
from universe.generator import build_universe, PIXEL_COLORS
from simulation_engine import SimulationEngine

def plot_frame(pos, types, out_path, extent=50):
    fig, ax = plt.subplots(figsize=(8, 8), facecolor='black')
    ax.set_facecolor('black')
    
    for t in np.unique(types):
        mask = (types == t)
        color = np.array(PIXEL_COLORS.get(t, (255,255,255))) / 255.0
        ax.scatter(pos[mask, 0], pos[mask, 1], s=0.5, color=color, alpha=0.8)
        
    ax.set_xlim(-extent, extent)
    ax.set_ylim(-extent, extent)
    ax.axis('off')
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches='tight', facecolor='black')
    plt.close()

def main():
    preset = sys.argv[1] if len(sys.argv) > 1 else "cartwheel_galaxy"
    print(f"Testing preset {preset} for 100,000 frames...")
    
    pos, vel, mass, types = build_universe(preset=preset, N_total=3000, seed=42)
    engine = SimulationEngine(pos, vel, mass, types, dt=0.003, eps=1.0)
    engine.warmup()
    
    out_dir = os.path.join(os.path.dirname(__file__), "scratch")
    os.makedirs(out_dir, exist_ok=True)
    
    frames_to_save = [0, 25000, 50000, 75000, 100000]
    
    for step in range(100001):
        if step in frames_to_save:
            out_path = os.path.join(out_dir, f"{preset}_step{step}.png")
            plot_frame(engine.pos, engine.types, out_path, extent=60)
            print(f"Saved {out_path}")
        engine.step()
        if step % 10000 == 0:
            print(f"Step {step}/100000")

if __name__ == '__main__':
    main()
