import time
from universe.generator import build_universe
from hermite_engine import HermiteEngine

pos, vel, mass, types = build_universe(preset="omega_centauri", N_total=5000)
engine = HermiteEngine(pos, vel, mass, types, G=1.0, eps=1.0)
engine.theta = 1.2

engine.step(n_substeps=2, speed_mult=1.0)
t0 = time.time()
for _ in range(60):
    engine.step(n_substeps=32, speed_mult=1.0)
t1 = time.time()
print(f"FPS with theta=1.2: {60/(t1-t0):.1f}")
