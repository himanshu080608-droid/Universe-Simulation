import sys
import numpy as np
from universe.generator import build_universe
from hermite_engine import HermiteEngine

print("Building Castor Sextuple preset...")
pos, vel, mass, types = build_universe(preset="castor_sextuple", N_total=6)

print("Initializing CPU Hermite Engine...")
engine = HermiteEngine(pos, vel, mass, types, G=1.0, eps=1.0, dt=0.001)

initial_dist_A = np.linalg.norm(engine.pos[0] - engine.pos[1])
initial_dist_B = np.linalg.norm(engine.pos[2] - engine.pos[3])
initial_dist_C = np.linalg.norm(engine.pos[4] - engine.pos[5])
print(f"Initial Separation A (Straggler-Dwarf): {initial_dist_A:.4f} AU")
print(f"Initial Separation B (Straggler-Dwarf): {initial_dist_B:.4f} AU")
print(f"Initial Separation C (Dwarf-Dwarf):     {initial_dist_C:.4f} AU")

steps_per_batch = 100000
batches = 10  # Total 1,000,000 steps

min_A, min_B, min_C = float('inf'), float('inf'), float('inf')
max_A, max_B, max_C = 0.0, 0.0, 0.0

for b in range(batches):
    engine.step(n_substeps=steps_per_batch, speed_mult=1.0)
    
    dist_A = np.linalg.norm(engine.pos[0] - engine.pos[1])
    dist_B = np.linalg.norm(engine.pos[2] - engine.pos[3])
    dist_C = np.linalg.norm(engine.pos[4] - engine.pos[5])
    
    min_A = min(min_A, dist_A); max_A = max(max_A, dist_A)
    min_B = min(min_B, dist_B); max_B = max(max_B, dist_B)
    min_C = min(min_C, dist_C); max_C = max(max_C, dist_C)
    
    print(f"  [Batch {b+1}/10] Separation A: {dist_A:.4f} | B: {dist_B:.4f} | C: {dist_C:.4f}")
    sys.stdout.flush()

if min_A < 2.0 or min_B < 2.0 or min_C < 2.0:
    print("❌ FAILED: One of the binaries spiraled in!")
else:
    print("✅ SUCCESS: ALL 3 binaries are perfectly stable over 1,000,000 steps!")
