import os
import sys
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from universe.generator import build_universe
from simulation_engine import SimulationEngine

def create_preset_gif(preset, frames=100, steps_per_frame=100, filename=None):
    if filename is None:
        filename = f"{preset}.gif"
    
    print(f"Generating GIF for {preset}...")
    pos, vel, mass, types = build_universe(preset, N_total=2000, seed=42)
    
    engine = SimulationEngine(pos, vel, mass, types, dt=0.003)
    
    images = []
    
    def render_to_image(engine_pos, types_arr):
        # Determine camera bounds dynamically to "zoom in and out"
        r = np.linalg.norm(engine_pos, axis=1)
        mask = types_arr != 2
        fp = engine_pos[mask] if np.any(mask) else engine_pos
        
        if len(fp) > 0:
            cx, cy = np.median(fp[:,0]), np.median(fp[:,1])
        else:
            cx, cy = 0.0, 0.0
            
        r_fp = np.linalg.norm(fp - np.array([cx, cy]), axis=1)
        base_span = max(np.percentile(r_fp, 90) * 1.5, 2.0)
        
        # Dynamic zoom: 1.0x -> 10.0x -> 1.0x over 100 frames
        frame_idx = len(images)
        if frame_idx < 50:
            zoom = 1.0 + (9.0 * frame_idx / 50.0)
        else:
            zoom = 10.0 - (9.0 * (frame_idx - 50) / 50.0)
            
        span = base_span / zoom
        
        # Create a 400x400 image
        img = Image.new('RGB', (400, 400), (0, 0, 0))
        pixels = img.load()
        
        scale = 200.0 / span
        
        # Simple colors
        colors = {
            0: (255, 255, 0),    # Star (Yellow)
            1: (100, 100, 255),  # Planet (Blue)
            2: (150, 255, 150),  # Comet (Green)
            3: (255, 100, 0),    # Rocky (Orange)
            4: (150, 0, 200),    # Gas (Purple)
            5: (255, 0, 0),      # BH (Red)
            11: (200, 50, 50),   # Red Dwarf (Dark Red)
            12: (150, 150, 150), # Asteroid (Grey)
        }
        
        for i in range(len(engine_pos)):
            px = int((engine_pos[i, 0] - cx) * scale + 200)
            py = int((engine_pos[i, 1] - cy) * scale + 200)
            if 0 <= px < 400 and 0 <= py < 400:
                c = colors.get(int(types_arr[i]), (255, 255, 255))
                pixels[px, py] = c
                
        return img
    
    for frame in range(frames):
        img = render_to_image(engine.pos, types)
        images.append(img)
        engine.step(steps_per_frame)
        
    images[0].save(filename, save_all=True, append_images=images[1:], optimize=False, duration=50, loop=0)
    print(f"Saved {filename}")

if __name__ == "__main__":
    presets_to_test = [
        "ngc1052_df2", "castor_sextuple", "hd98800_polar", 
        "trappist_1", "shepherd_moons", "wr104_pinwheel", 
        "omega_centauri", "pleiades_m45", "hl_tauri"
    ]
    for p in presets_to_test:
        create_preset_gif(p, frames=100, steps_per_frame=1000)
