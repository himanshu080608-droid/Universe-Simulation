import os
import sys
import pygame
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(__file__))
from universe.generator import build_universe
from renderer.pygame_renderer import PygameRenderer
from simulation_engine import SimulationEngine

presets = [
    "ngc1052_df2", "castor_sextuple", "hd98800_polar",
    "trappist_1", "shepherd_moons", "wr104_pinwheel", "omega_centauri",
    "pleiades_m45", "hl_tauri"
]

os.environ["SDL_VIDEODRIVER"] = "dummy"
pygame.init()
pygame.display.set_mode((800, 800))

out_dir = os.path.join(os.path.dirname(__file__), "debug_frames")
os.makedirs(out_dir, exist_ok=True)

for preset in presets:
    print(f"Rendering {preset}...")
    try:
        pos, vel, mass, types = build_universe(preset, N_total=2000, seed=42)
        engine = SimulationEngine(pos, vel, mass, types, dt=0.003, eps=1.0)
        renderer = PygameRenderer(width=800, height=800, trail_decay=0.88)
        
        # Center camera
        cx, cy = 0.0, 0.0
        mask = types != 2
        fp = pos[mask] if np.any(mask) else pos
        if len(fp) > 0:
            cx, cy = np.median(fp[:,0]), np.median(fp[:,1])
            r = np.linalg.norm(fp - np.array([cx, cy]), axis=1)
            span = max(np.percentile(r, 90) * 2.5, 1.0)
        else:
            span = 50.0
            
        zoom = min(800, 800) * 0.45 / span
        renderer.camera.zoom = zoom
        renderer.camera.offset = np.array([400 - cx * zoom, 400 + cy * zoom], dtype=np.float64)
        
        # Frame 0
        renderer.render_frame(engine.pos, engine.types, mass=engine.mass, energy=None, step=0, steps_per_frame=1)
        arr = pygame.surfarray.array3d(renderer.screen)
        arr = np.transpose(arr, (1, 0, 2))
        Image.fromarray(arr).save(os.path.join(out_dir, f"{preset}_t0.png"))
        
        # Frame 500
        for _ in range(500):
            engine.step(1)
            
        renderer.render_frame(engine.pos, engine.types, mass=engine.mass, energy=None, step=500, steps_per_frame=1)
        arr = pygame.surfarray.array3d(renderer.screen)
        arr = np.transpose(arr, (1, 0, 2))
        Image.fromarray(arr).save(os.path.join(out_dir, f"{preset}_t500.png"))
        print(f"  Saved {preset}")
    except Exception as e:
        print(f"  Error on {preset}: {e}")
