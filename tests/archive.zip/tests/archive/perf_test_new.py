import time
from hermite_engine import HermiteEngine
from universe.generator import build_universe

p, v, m, t = build_universe("castor_sextuple", N_total=5000, seed=42)
engine = HermiteEngine(p, v, m, t, dt=0.003, eps=1.0, theta=0.8)

spf = 2
speed_mult = 16.0
dt_base = 0.001

target_time_delta = spf * dt_base * speed_mult
n_sub = max(1, int(round(target_time_delta / engine.dt)))

print(f"Calculated n_sub: {n_sub} steps per frame (down from 32!)")

t0 = time.perf_counter()
engine.step(n_substeps=n_sub, speed_mult=1.0)
elapsed = time.perf_counter() - t0

fps = 1.0 / elapsed
print(f"Frame time: {elapsed*1000:.1f}ms  ->  {fps:.1f} FPS")
