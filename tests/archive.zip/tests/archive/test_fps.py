import time
import numpy as np
import warnings
warnings.filterwarnings('ignore')
from universe.generator import build_universe
from hermite_engine import HermiteEngine

presets = ["castor_sextuple", "solar_system", "omega_centauri"]

for preset in presets:
    print(f"\n--- Benchmarking: {preset} ---")
    pos, vel, mass, types = build_universe(preset=preset, N_total=5000)
    engine = HermiteEngine(pos, vel, mass, types, G=1.0, eps=1.0)
    
    # warmup (numba jit)
    engine.step(n_substeps=2, speed_mult=1.0)
    
    for speed in [1, 4, 16]:
        spf = 2
        n_sub = int(round(spf * speed))
        
        # run 60 frames
        t0 = time.time()
        for _ in range(60):
            engine.step(n_substeps=spf, speed_mult=speed)
        t1 = time.time()
        
        elapsed = t1 - t0
        fps = 60.0 / elapsed
        print(f"Speed {speed}x (n_sub={n_sub}): {fps:.1f} FPS")

