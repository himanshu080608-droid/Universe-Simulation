import time
from hermite_engine import HermiteEngine
from universe.generator import build_universe

p, v, m, t = build_universe("castor_sextuple", N_total=5000)
engine = HermiteEngine(p, v, m, t, dt=0.001, eps=1.0, theta=0.8)

t0 = time.perf_counter()
engine.step(n_substeps=2, speed_mult=1.0)
elapsed = time.perf_counter() - t0
print(f"Hermite frame took: {elapsed*1000:.2f} ms")
