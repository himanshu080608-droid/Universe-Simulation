import numpy as np
from universe.generator import build_universe
from hermite_engine import HermiteEngine

print("Building Castor Sextuple preset...")
pos, vel, mass, types = build_universe(preset="castor_sextuple", N_total=6)

print("Initializing CPU Hermite Engine...")
engine = HermiteEngine(pos, vel, mass, types, G=1.0, eps=1.0, dt=0.001)

initial_dist = np.linalg.norm(engine.pos[0] - engine.pos[1])
print(f"Initial separation of inner binary A: {initial_dist:.4f} AU")

steps_per_batch = 10000
batches = 10

min_dist = float('inf')
max_dist = 0.0

for b in range(batches):
    engine.step(n_substeps=10000, speed_mult=1.0)
    
    dist = np.linalg.norm(engine.pos[0] - engine.pos[1])
    min_dist = min(min_dist, dist)
    max_dist = max(max_dist, dist)
    
    print(f"  [Batch {b+1}/10] Separation: {dist:.4f} AU (Min: {min_dist:.4f}, Max: {max_dist:.4f})")
