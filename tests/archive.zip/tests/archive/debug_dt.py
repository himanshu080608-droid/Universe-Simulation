from simulation_engine import SimulationEngine
from universe.generator import build_universe
import numpy as np

p, v, m, t = build_universe("castor_sextuple", N_total=5000)
engine = SimulationEngine(p, v, m, t, dt=0.1, eps=1.0)
for step in range(500): # 500 * 0.1 = 50.0 seconds
    engine.step()
    if step % 100 == 0:
        star_p = engine.pos[:6]
        dist_C = np.linalg.norm(star_p[4] - star_p[5])
        print(f"Step {step:4d} | dt=0.1 | C: {dist_C:.3f}")
