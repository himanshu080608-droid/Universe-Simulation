from simulation_engine import SimulationEngine
from universe.generator import build_universe
import numpy as np

p, v, m, t = build_universe("castor_sextuple", N_total=5000)
engine = SimulationEngine(p, v, m, t, dt=0.001, eps=1.0)
for step in range(25000):
    engine.step()
    if step % 5000 == 0:
        star_p = engine.pos[:6]
        # AB1: 0 and 1. AB2: 2 and 3. C: 4 and 5.
        dist_AB1 = np.linalg.norm(star_p[0] - star_p[1])
        dist_AB2 = np.linalg.norm(star_p[2] - star_p[3])
        dist_C   = np.linalg.norm(star_p[4] - star_p[5])
        print(f"Step {step:5d} | AB1: {dist_AB1:.3f} | AB2: {dist_AB2:.3f} | C: {dist_C:.3f}")
