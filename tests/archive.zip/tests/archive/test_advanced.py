import time
from universe.generator import build_universe
from advanced_engine import AdvancedTaichiEngine

print("Building universe (5000 particles)...")
pos, vel, mass, types = build_universe(preset="omega_centauri", N_total=5000)

print("Initializing Advanced Taichi Engine (GPU + Ahmad-Cohen)...")
engine = AdvancedTaichiEngine(pos, vel, mass, types, G=1.0, eps=1.0)

print("Benchmarking 16x speed (32 substeps/frame)...")
t0 = time.time()
for _ in range(60):
    engine.step(n_substeps=32, speed_mult=1.0)
t1 = time.time()

fps = 60.0 / (t1 - t0)
print(f"--- Advanced FPS (5000 particles at 16x speed): {fps:.1f} ---")
